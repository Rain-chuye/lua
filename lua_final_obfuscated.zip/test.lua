print("Hello Commercial Obfuscated Lua!")
local a = 123
local b = 456
print("Sum is: " .. (a + b))
